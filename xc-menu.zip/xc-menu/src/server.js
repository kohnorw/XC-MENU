'use strict';

const express = require('express');
const axios   = require('axios');
const Database = require('better-sqlite3');
const cron    = require('node-cron');
const crypto  = require('crypto');
const path    = require('path');

const app = express();
app.use(express.json());

const PORT = parseInt(process.env.PORT || '3000');

// ─── Database ─────────────────────────────────────────────────────────────────
const db = new Database('/data/users.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS sub_users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT    NOT NULL UNIQUE,
    password        TEXT    NOT NULL,
    display_name    TEXT,
    expires_at      TEXT,
    max_connections INTEGER DEFAULT 1,
    notes           TEXT,
    active          INTEGER DEFAULT 1,
    created_at      TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS config (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

// ─── Migration: clear hashes made with old salt so setup re-runs cleanly ────────
(function migrate() {
  const hash = db.prepare("SELECT value FROM config WHERE key='admin_pass_hash'").get();
  // Old hashes were 64-char hex made with a salt — if present and setup was done
  // before this fix, clear it so the user goes through setup again with the correct hash.
  // We detect the old hash by checking if it was made with a salted input.
  // Simplest safe approach: if admin_pass_hash exists but we cannot verify it without
  // the old salt, just keep it — but we wipe it so user re-does setup.
  // Only wipe if upstream is already configured (so they only redo the admin password step).
  if (hash) {
    // Test if the stored hash validates without salt (new format)
    // If not, it was made with the old salt — clear it to force re-setup of admin creds
    const testPass = '_probe_';
    const noSaltHash = require('crypto').createHash('sha256').update(testPass).digest('hex');
    // We cannot know the original password, so we always clear on first boot after this update
    // Only clear once by checking a migration flag
    const migrated = db.prepare("SELECT value FROM config WHERE key='migration_v2'").get();
    if (!migrated) {
      db.prepare("DELETE FROM config WHERE key='admin_pass_hash'").run();
      db.prepare("DELETE FROM config WHERE key='admin_user'").run();
      db.prepare("INSERT OR REPLACE INTO config (key, value) VALUES ('migration_v2', '1')").run();
      console.log('[migration] Cleared admin credentials — please re-run setup to set a new password.');
    }
  }
})();

// ─── Config helpers (stored in DB, env vars as fallback) ─────────────────────
function getConfig(key) {
  const row = db.prepare('SELECT value FROM config WHERE key = ?').get(key);
  return row ? row.value : null;
}

function setConfig(key, value) {
  db.prepare('INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)').run(key, String(value));
}

function isSetupComplete() {
  return !!(getConfig('admin_user') && getConfig('admin_pass_hash') && getConfig('upstream_url'));
}

function hashPassword(pass) {
  return crypto.createHash('sha256').update(pass).digest('hex');
}

function checkPassword(pass, hash) {
  return hashPassword(pass) === hash;
}

function getUpstreamConfig() {
  return {
    url:      getConfig('upstream_url')      || process.env.UPSTREAM_URL      || '',
    username: getConfig('upstream_username') || process.env.UPSTREAM_USERNAME || '',
    password: getConfig('upstream_password') || process.env.UPSTREAM_PASSWORD || '',
  };
}

// ─── Session store (in-memory, 24h TTL) ──────────────────────────────────────
const sessions = new Map();

function createSession() {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { created_at: Date.now() });
  return token;
}

function validateSession(token) {
  if (!token) return false;
  const s = sessions.get(token);
  if (!s) return false;
  if (Date.now() - s.created_at > 86400000) { sessions.delete(token); return false; }
  return true;
}

// ─── Middleware: require setup complete ───────────────────────────────────────
function requireSetup(req, res, next) {
  if (!isSetupComplete()) {
    return res.status(503).json({ error: 'Setup not complete', setup_required: true });
  }
  next();
}

// ─── Admin auth middleware ─────────────────────────────────────────────────────
function adminAuth(req, res, next) {
  if (!isSetupComplete()) return res.status(503).json({ error: 'Setup required', setup_required: true });
  const token = req.headers['x-session-token'];
  if (validateSession(token)) return next();
  res.status(401).json({ error: 'Unauthorized' });
}

// ─── Channel / VOD / Series cache ────────────────────────────────────────────
const channelCache = new Map(); // stream_id -> channel_name
let streamCache        = [];    // live streams
let liveCategoryCache  = [];    // live categories
let vodCache           = [];    // VOD streams
let vodCategoryCache   = [];    // VOD categories
let seriesCache        = [];    // series
let seriesCategoryCache= [];    // series categories

async function fetchAction(cfg, action) {
  const res = await axios.get(`${cfg.url}/player_api.php`, {
    params: { username: cfg.username, password: cfg.password, action },
    timeout: 30000,
  });
  return Array.isArray(res.data) ? res.data : [];
}

async function refreshChannelCache() {
  try {
    const cfg = getUpstreamConfig();
    if (!cfg.url) return;
    console.log('[cache] Refreshing all stream data...');

    const [live, liveCats, vod, vodCats, series, seriesCats] = await Promise.allSettled([
      fetchAction(cfg, 'get_live_streams'),
      fetchAction(cfg, 'get_live_categories'),
      fetchAction(cfg, 'get_vod_streams'),
      fetchAction(cfg, 'get_vod_categories'),
      fetchAction(cfg, 'get_series'),
      fetchAction(cfg, 'get_series_categories'),
    ]);

    if (live.status === 'fulfilled') {
      streamCache = live.value;
      channelCache.clear();
      for (const ch of streamCache) {
        channelCache.set(String(ch.stream_id), ch.name || String(ch.stream_id));
      }
      console.log(`[cache] Live: ${streamCache.length} streams`);
    }
    if (liveCats.status === 'fulfilled')   { liveCategoryCache   = liveCats.value;   console.log(`[cache] Live categories: ${liveCategoryCache.length}`); }
    if (vod.status === 'fulfilled')        { vodCache            = vod.value;         console.log(`[cache] VOD: ${vodCache.length}`); }
    if (vodCats.status === 'fulfilled')    { vodCategoryCache    = vodCats.value;     console.log(`[cache] VOD categories: ${vodCategoryCache.length}`); }
    if (series.status === 'fulfilled')     { seriesCache         = series.value;      console.log(`[cache] Series: ${seriesCache.length}`); }
    if (seriesCats.status === 'fulfilled') { seriesCategoryCache = seriesCats.value;  console.log(`[cache] Series categories: ${seriesCategoryCache.length}`); }

  } catch (e) {
    console.warn('[cache] Refresh error:', e.message);
  }
}

// Refresh on startup and every 6 hours
setTimeout(refreshChannelCache, 3000);
setInterval(refreshChannelCache, 6 * 60 * 60 * 1000);

// ─── Active connection tracker ────────────────────────────────────────────────
const activeConnections = new Map();

function getActiveConnectionsForUser(username) {
  let count = 0;
  for (const c of activeConnections.values()) { if (c.username === username) count++; }
  return count;
}

function getAllActiveConnections() {
  return [...activeConnections.entries()].map(([id, c]) => ({
    id,
    username: c.username,
    stream_id: c.stream_id,
    stream_name: channelCache.get(c.stream_id) || c.stream_name || c.stream_id,
    started_at: c.started_at
  }));
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function genPassword(len = 12) {
  return crypto.randomBytes(len).toString('base64url').slice(0, len);
}

function isExpired(user) {
  if (!user.expires_at) return false;
  return new Date(user.expires_at) < new Date();
}

function lookupUser(username, password) {
  const user = db.prepare('SELECT * FROM sub_users WHERE username = ?').get(username);
  if (!user || user.password !== password || !user.active || isExpired(user)) return null;
  return user;
}

function daysUntilExpiry(expiresAt) {
  if (!expiresAt) return null;
  return Math.ceil((new Date(expiresAt) - new Date()) / (1000 * 60 * 60 * 24));
}

async function upstreamXC(params) {
  const cfg = getUpstreamConfig();
  const res = await axios.get(`${cfg.url}/player_api.php`, {
    params: { ...params, username: cfg.username, password: cfg.password },
    timeout: 15000,
  });
  return res.data;
}

// ─── Setup API ────────────────────────────────────────────────────────────────

// Check if setup is needed
app.get('/admin/api/setup/status', (req, res) => {
  res.json({ setup_required: !isSetupComplete() });
});

// Step 1: save admin credentials
app.post('/admin/api/setup/admin', (req, res) => {
  if (isSetupComplete()) return res.status(400).json({ error: 'Already configured' });
  const { username, password } = req.body;
  if (!username || !password || password.length < 6) {
    return res.status(400).json({ error: 'Username and password (min 6 chars) are required' });
  }
  setConfig('admin_user', username);
  setConfig('admin_pass_hash', hashPassword(password));
  res.json({ ok: true });
});

// Step 2: test + save upstream XC-Menu config
app.post('/admin/api/setup/upstream', async (req, res) => {
  // Allow during setup OR by authenticated admin (for changing later)
  const token = req.headers['x-session-token'];
  if (isSetupComplete() && !validateSession(token)) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { url, username, password } = req.body;
  if (!url || !username || !password) {
    return res.status(400).json({ error: 'url, username and password are required' });
  }

  const cleanUrl = url.replace(/\/$/, '');

  // Test connection
  try {
    const testRes = await axios.get(`${cleanUrl}/player_api.php`, {
      params: { username, password },
      timeout: 10000,
    });
    if (!testRes.data?.user_info?.auth) {
      return res.status(400).json({ error: 'Server rejected these credentials. Check your XC username and password.' });
    }
  } catch (e) {
    return res.status(400).json({ error: `Could not reach server: ${e.message}` });
  }

  setConfig('upstream_url', cleanUrl);
  setConfig('upstream_username', username);
  setConfig('upstream_password', password);

  // If setup just completed, issue a session token
  if (!isSetupComplete()) {
    return res.json({ ok: true });
  }

  const newToken = createSession();
  res.json({ ok: true, token: newToken });
});

// Complete setup — called after both steps done, issues session token
app.post('/admin/api/setup/complete', (req, res) => {
  if (!getConfig('admin_user') || !getConfig('upstream_url')) {
    return res.status(400).json({ error: 'Complete both setup steps first' });
  }
  const token = createSession();
  res.json({ ok: true, token });
});

// ─── Admin login / logout ─────────────────────────────────────────────────────
app.post('/admin/api/login', requireSetup, (req, res) => {
  const { username, password } = req.body;
  const storedUser = getConfig('admin_user');
  const storedHash = getConfig('admin_pass_hash');
  if (username === storedUser && checkPassword(password, storedHash)) {
    return res.json({ ok: true, token: createSession() });
  }
  res.status(401).json({ ok: false, error: 'Invalid credentials' });
});

app.post('/admin/api/logout', (req, res) => {
  const token = req.headers['x-session-token'];
  if (token) sessions.delete(token);
  res.json({ ok: true });
});

// ─── Admin settings: change upstream config ───────────────────────────────────
app.get('/admin/api/settings', adminAuth, (req, res) => {
  const cfg = getUpstreamConfig();
  res.json({
    upstream_url: cfg.url,
    upstream_username: cfg.username,
    admin_user: getConfig('admin_user'),
  });
});

app.patch('/admin/api/settings/admin', adminAuth, (req, res) => {
  const { username, current_password, new_password } = req.body;
  const storedHash = getConfig('admin_pass_hash');
  if (!checkPassword(current_password, storedHash)) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }
  if (username) setConfig('admin_user', username);
  if (new_password) {
    if (new_password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    setConfig('admin_pass_hash', hashPassword(new_password));
  }
  res.json({ ok: true });
});

// ─── Static pages ─────────────────────────────────────────────────────────────
app.get('/admin/setup', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin/setup.html'));
});

app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin/login.html'));
});

// /admin/dashboard serves the main app — no setup redirect loop
app.get(['/admin/dashboard', '/admin/dashboard/'], (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin/index.html'));
});

// /admin and /admin/ redirect to login (which handles the flow from there)
app.get(['/admin', '/admin/'], (req, res) => {
  res.redirect('/admin/login');
});

// ─── XC API proxy ─────────────────────────────────────────────────────────────
app.get('/player_api.php', async (req, res) => {
  if (!isSetupComplete()) return res.status(503).json({ error: 'Service not configured' });
  const { username, password, action } = req.query;
  const user = lookupUser(username, password);
  if (!user) {
    return res.json({
      user_info: { auth: 0, status: 'Expired', message: 'Invalid credentials or expired account' },
      server_info: {}
    });
  }

  if (!action) {
    const activeCons = getActiveConnectionsForUser(user.username);
    return res.json({
      user_info: {
        auth: 1, status: 'Active',
        username: user.username, password: user.password,
        message: '',
        exp_date: user.expires_at ? String(Math.floor(new Date(user.expires_at).getTime() / 1000)) : null,
        is_trial: '0',
        active_cons: String(activeCons),
        created_at: String(Math.floor(new Date(user.created_at).getTime() / 1000)),
        max_connections: String(user.max_connections),
        allowed_output_formats: ['m3u8', 'ts', 'rtmp'],
      },
      server_info: {
        url: req.hostname, port: String(PORT), https_port: String(PORT),
        server_protocol: req.protocol, rtmp_port: '0', timezone: 'UTC',
        timestamp_now: Math.floor(Date.now() / 1000), time_now: new Date().toISOString(),
      }
    });
  }

  // Serve from local cache where possible — avoids upstream timeouts
  if (action === 'get_live_streams') {
    if (streamCache.length === 0) await refreshChannelCache();
    return res.json(streamCache);
  }
  if (action === 'get_live_categories') {
    if (liveCategoryCache.length === 0) await refreshChannelCache();
    return res.json(liveCategoryCache);
  }
  if (action === 'get_vod_streams') {
    if (vodCache.length === 0) await refreshChannelCache();
    return res.json(vodCache);
  }
  if (action === 'get_vod_categories') {
    if (vodCategoryCache.length === 0) await refreshChannelCache();
    return res.json(vodCategoryCache);
  }
  if (action === 'get_series') {
    if (seriesCache.length === 0) await refreshChannelCache();
    return res.json(seriesCache);
  }
  if (action === 'get_series_categories') {
    if (seriesCategoryCache.length === 0) await refreshChannelCache();
    return res.json(seriesCategoryCache);
  }

  // Everything else (EPG, series info, stream info etc.) — proxy upstream
  try {
    const { username: _u, password: _p, ...upstreamParams } = req.query;
    return res.json(await upstreamXC(upstreamParams));
  } catch (e) {
    console.error('Upstream XC error:', e.message);
    return res.status(502).json({ error: 'Upstream error', detail: e.message });
  }
});

// ─── M3U playlist — built locally from cached channel list ───────────────────
app.get('/get.php', async (req, res) => {
  if (!isSetupComplete()) return res.status(503).send('Service not configured');
  const { username, password } = req.query;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');

  const host = `${req.protocol}://${req.get('host')}`;

  // Fill cache if empty
  if (streamCache.length === 0) await refreshChannelCache();

  // Build M3U locally from cache — fast, no upstream timeout risk
  if (streamCache.length > 0) {
    const lines = ['#EXTM3U'];
    for (const ch of streamCache) {
      const epgId  = ch.epg_channel_id ? ` tvg-id="${xmlEsc(ch.epg_channel_id)}"` : '';
      const logo   = ch.stream_icon    ? ` tvg-logo="${xmlEsc(ch.stream_icon)}"` : '';
      const group  = xmlEsc(ch.category_name || 'Uncategorized');
      const name   = xmlEsc(ch.name || String(ch.stream_id));
      lines.push(`#EXTINF:-1${epgId}${logo} tvg-name="${name}" group-title="${group}",${ch.name || ch.stream_id}`);
      lines.push(`${host}/live/${username}/${password}/${ch.stream_id}.ts`);
    }
    res.set('Content-Type', 'application/x-mpegurl; charset=utf-8');
    return res.send(lines.join('\n'));
  }

  // Fallback: proxy from upstream if cache still empty
  const cfg = getUpstreamConfig();
  try {
    const upstream = await axios.get(`${cfg.url}/get.php`, {
      params: { username: cfg.username, password: cfg.password, type: 'm3u_plus', output: 'ts' },
      responseType: 'text', timeout: 60000,
    });
    const m3u = upstream.data
      .replace(new RegExp(cfg.url.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&'), 'g'), host)
      .replace(new RegExp(`/${cfg.username}/${cfg.password}/`, 'g'), `/${username}/${password}/`);
    res.set('Content-Type', 'application/x-mpegurl; charset=utf-8');
    return res.send(m3u);
  } catch (e) {
    console.error('M3U fallback error:', e.message);
    return res.status(502).send('Could not load playlist');
  }
});

function xmlEsc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ─── EPG proxy ────────────────────────────────────────────────────────────────
async function serveEPG(req, res) {
  if (!isSetupComplete()) return res.status(503).send('Service not configured');
  const { username, password } = req.query;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');
  const cfg = getUpstreamConfig();
  try {
    const upstream = await axios.get(`${cfg.url}/xmltv.php`, {
      params: { username: cfg.username, password: cfg.password },
      responseType: 'stream', timeout: 120000,
    });
    res.set('Content-Type', upstream.headers['content-type'] || 'application/xml');
    upstream.data.pipe(res);
    req.on('close', () => upstream.data.destroy());
  } catch (e) {
    return res.status(502).send('Upstream EPG error');
  }
}
app.get('/xmltv.php', serveEPG);
app.get('/epg', serveEPG);

// ─── Stream proxy ─────────────────────────────────────────────────────────────
app.get('/live/:username/:password/:streamFile', async (req, res) => {
  if (!isSetupComplete()) return res.status(503).send('Service not configured');
  const { username, password, streamFile } = req.params;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');
  if (getActiveConnectionsForUser(username) >= user.max_connections) return res.status(403).send('Max connections reached');

  const cfg = getUpstreamConfig();
  const connId = crypto.randomUUID();
  const streamId = streamFile.split('.')[0];
  // Look up channel name from cache
  const channelName = channelCache.get(streamId) || streamFile;
  activeConnections.set(connId, { username, stream_id: streamId, stream_name: channelName, started_at: new Date().toISOString(), res, upstream: null });
  console.log(`[stream] OPEN  ${username} -> ${channelName}`);

  try {
    const upstreamReq = await axios.get(`${cfg.url}/live/${cfg.username}/${cfg.password}/${streamFile}`, { responseType: 'stream', timeout: 10000 });
    // Store upstream so kick can destroy it
    const conn = activeConnections.get(connId);
    if (conn) conn.upstream = upstreamReq.data;
    res.set('Content-Type', upstreamReq.headers['content-type'] || 'video/mp2t');
    upstreamReq.data.pipe(res);
    upstreamReq.data.on('error', () => { activeConnections.delete(connId); res.end(); });
    req.on('close', () => { activeConnections.delete(connId); upstreamReq.data.destroy(); console.log(`[stream] CLOSE ${username} -> ${channelName}`); });
  } catch (e) {
    activeConnections.delete(connId);
    res.status(502).send('Stream error');
  }
});

app.get('/:type(timeshift|movie|series)/:username/:password/*', async (req, res) => {
  if (!isSetupComplete()) return res.status(503).send('Service not configured');
  const { username, password, type } = req.params;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');
  if (getActiveConnectionsForUser(username) >= user.max_connections) return res.status(403).send('Max connections reached');

  const cfg = getUpstreamConfig();
  const rest = req.params[0];
  const connId = crypto.randomUUID();
  activeConnections.set(connId, { username, stream_id: rest, stream_name: `${type}/${rest}`, started_at: new Date().toISOString(), res });

  try {
    const upstream = await axios.get(`${cfg.url}/${type}/${cfg.username}/${cfg.password}/${rest}`, { responseType: 'stream', timeout: 10000 });
    res.set('Content-Type', upstream.headers['content-type'] || 'video/mp2t');
    upstream.data.pipe(res);
    req.on('close', () => { activeConnections.delete(connId); upstream.data.destroy(); });
    upstream.data.on('error', () => { activeConnections.delete(connId); res.end(); });
  } catch (e) {
    activeConnections.delete(connId);
    res.status(502).send('Stream error');
  }
});

// ─── Admin API ────────────────────────────────────────────────────────────────

app.get('/admin/api/connections', adminAuth, (req, res) => res.json(getAllActiveConnections()));

app.get('/admin/api/users', adminAuth, (req, res) => {
  const users = db.prepare('SELECT * FROM sub_users ORDER BY created_at DESC').all();
  res.json(users.map(u => ({ ...u, days_remaining: daysUntilExpiry(u.expires_at) })));
});

app.post('/admin/api/users', adminAuth, (req, res) => {
  const { username, password, display_name, expires_at, max_connections, notes } = req.body;
  if (!username) return res.status(400).json({ error: 'username is required' });
  const pass = password || genPassword();
  try {
    const info = db.prepare(`INSERT INTO sub_users (username, password, display_name, expires_at, max_connections, notes) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(username, pass, display_name || username, expires_at || null, max_connections || 1, notes || null);
    const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json({ ...user, days_remaining: daysUntilExpiry(user.expires_at) });
  } catch (e) {
    if (e.message.includes('UNIQUE')) return res.status(409).json({ error: 'Username already exists' });
    res.status(500).json({ error: e.message });
  }
});

app.patch('/admin/api/users/:id', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  const { display_name, expires_at, max_connections, notes, active, password } = req.body;
  db.prepare(`UPDATE sub_users SET display_name=COALESCE(?,display_name), expires_at=?, max_connections=COALESCE(?,max_connections), notes=COALESCE(?,notes), active=COALESCE(?,active), password=COALESCE(?,password) WHERE id=?`
  ).run(display_name ?? null, expires_at !== undefined ? expires_at : user.expires_at, max_connections ?? null, notes ?? null, active !== undefined ? (active ? 1 : 0) : null, password ?? null, req.params.id);
  const updated = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  res.json({ ...updated, days_remaining: daysUntilExpiry(updated.expires_at) });
});

app.post('/admin/api/users/:id/renew', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  const days = parseInt(req.body.days || 30);
  const base = user.expires_at && new Date(user.expires_at) > new Date() ? new Date(user.expires_at) : new Date();
  base.setDate(base.getDate() + days);
  const newExpiry = base.toISOString().slice(0, 10);
  db.prepare('UPDATE sub_users SET expires_at = ?, active = 1 WHERE id = ?').run(newExpiry, req.params.id);
  res.json({ ...db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id), days_remaining: daysUntilExpiry(newExpiry) });
});

app.delete('/admin/api/users/:id', adminAuth, (req, res) => {
  if (!db.prepare('SELECT id FROM sub_users WHERE id = ?').get(req.params.id)) return res.status(404).json({ error: 'Not found' });
  db.prepare('DELETE FROM sub_users WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

app.get('/admin/api/users/:id/xc-info', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  const base = `${req.protocol}://${req.get('host')}`;
  res.json({
    server_url: base,
    username: user.username, password: user.password,
    m3u_url: `${base}/get.php?username=${user.username}&password=${user.password}&type=m3u_plus`,
    epg_url: `${base}/xmltv.php?username=${user.username}&password=${user.password}`,
    xc_url:  `${base}/player_api.php?username=${user.username}&password=${user.password}`,
  });
});

app.get('/admin/api/stats', adminAuth, (req, res) => {
  res.json({
    total:   db.prepare('SELECT COUNT(*) as c FROM sub_users').get().c,
    active:  db.prepare("SELECT COUNT(*) as c FROM sub_users WHERE active=1 AND (expires_at IS NULL OR expires_at>=datetime('now'))").get().c,
    expired: db.prepare("SELECT COUNT(*) as c FROM sub_users WHERE expires_at IS NOT NULL AND expires_at<datetime('now')").get().c,
  });
});

app.get('/admin/api/test-upstream', adminAuth, async (req, res) => {
  try {
    const data = await upstreamXC({});
    res.json({ ok: true, upstream_user: data.user_info?.username || getUpstreamConfig().username });
  } catch (e) {
    res.status(502).json({ ok: false, error: e.message });
  }
});

// ─── Cron: disable expired users hourly ──────────────────────────────────────
cron.schedule('0 * * * *', () => {
  const result = db.prepare(`UPDATE sub_users SET active=0 WHERE active=1 AND expires_at IS NOT NULL AND expires_at<datetime('now')`).run();
  if (result.changes > 0) console.log(`[cron] Disabled ${result.changes} expired user(s)`);
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  const ready = isSetupComplete();
  console.log(`✅ XC-Menu running on port ${PORT}`);
  if (!ready) console.log(`   ⚠️  First-time setup required — visit http://localhost:${PORT}/admin/setup`);
  else        console.log(`   XC-Menu Admin: http://localhost:${PORT}/admin`);
});
