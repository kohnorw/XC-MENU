'use strict';

const express = require('express');
const axios = require('axios');
const Database = require('better-sqlite3');
const cron = require('node-cron');
const crypto = require('crypto');
const path = require('path');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ─── Config ──────────────────────────────────────────────────────────────────
const UPSTREAM_URL      = (process.env.UPSTREAM_URL || '').replace(/\/$/, '');
const UPSTREAM_USERNAME = process.env.UPSTREAM_USERNAME || '';
const UPSTREAM_PASSWORD = process.env.UPSTREAM_PASSWORD || '';
const ADMIN_USER        = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS        = process.env.ADMIN_PASS || 'admin';
const PORT              = parseInt(process.env.PORT || '3000');

if (!UPSTREAM_URL || !UPSTREAM_USERNAME || !UPSTREAM_PASSWORD) {
  console.error('ERROR: UPSTREAM_URL, UPSTREAM_USERNAME, UPSTREAM_PASSWORD must all be set.');
  process.exit(1);
}

// ─── Database ─────────────────────────────────────────────────────────────────
const db = new Database('/data/users.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS sub_users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT    NOT NULL UNIQUE,
    password    TEXT    NOT NULL,
    display_name TEXT,
    expires_at  TEXT,
    max_connections INTEGER DEFAULT 1,
    notes       TEXT,
    active      INTEGER DEFAULT 1,
    created_at  TEXT    DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS active_streams (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT NOT NULL,
    stream_id   TEXT NOT NULL,
    stream_name TEXT,
    started_at  TEXT DEFAULT (datetime('now'))
  );
`);

// ─── In-memory active connection tracker ─────────────────────────────────────
// Map of connectionId -> { username, stream_id, stream_name, started_at, res }
const activeConnections = new Map();

function getActiveConnectionsForUser(username) {
  let count = 0;
  for (const conn of activeConnections.values()) {
    if (conn.username === username) count++;
  }
  return count;
}

function getAllActiveConnections() {
  const result = [];
  for (const [id, conn] of activeConnections.entries()) {
    result.push({ id, username: conn.username, stream_id: conn.stream_id, stream_name: conn.stream_name, started_at: conn.started_at });
  }
  return result;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function genPassword(len = 12) {
  return crypto.randomBytes(len).toString('base64url').slice(0, len);
}

function isExpired(user) {
  if (!user.expires_at) return false;
  return new Date(user.expires_at) < new Date();
}

function lookupUser(username, password) {
  const user = db.prepare('SELECT * FROM sub_users WHERE username = ?').get(username);
  if (!user) return null;
  if (user.password !== password) return null;
  if (!user.active) return null;
  if (isExpired(user)) return null;
  return user;
}

function daysUntilExpiry(expiresAt) {
  if (!expiresAt) return null;
  const diff = new Date(expiresAt) - new Date();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

// ─── Simple admin auth middleware ─────────────────────────────────────────────
function adminAuth(req, res, next) {
  const auth = req.headers['authorization'] || '';
  const b64 = auth.replace('Basic ', '');
  if (!b64) return res.status(401).set('WWW-Authenticate', 'Basic realm="Admin"').send('Unauthorized');
  const [u, p] = Buffer.from(b64, 'base64').toString().split(':');
  if (u === ADMIN_USER && p === ADMIN_PASS) return next();
  res.status(401).set('WWW-Authenticate', 'Basic realm="Admin"').send('Unauthorized');
}

// ─── Upstream XC helper ───────────────────────────────────────────────────────
async function upstreamXC(params) {
  const url = `${UPSTREAM_URL}/player_api.php`;
  const res = await axios.get(url, {
    params: {
      ...params,
      username: UPSTREAM_USERNAME,
      password: UPSTREAM_PASSWORD,
    },
    timeout: 15000,
  });
  return res.data;
}

// ─── XC API proxy endpoint ────────────────────────────────────────────────────
// Clients hit /player_api.php?username=X&password=Y&action=...
app.get('/player_api.php', async (req, res) => {
  const { username, password, action } = req.query;

  const user = lookupUser(username, password);
  if (!user) {
    return res.json({
      user_info: { auth: 0, status: 'Expired', message: 'Invalid credentials or expired account' },
      server_info: {}
    });
  }

  // If no action — return auth/user info
  if (!action) {
    const days = daysUntilExpiry(user.expires_at);
    const activeCons = getActiveConnectionsForUser(user.username);
    return res.json({
      user_info: {
        auth: 1,
        status: 'Active',
        username: user.username,
        password: user.password,
        message: '',
        exp_date: user.expires_at ? String(Math.floor(new Date(user.expires_at).getTime() / 1000)) : null,
        is_trial: '0',
        active_cons: String(activeCons),
        created_at: String(Math.floor(new Date(user.created_at).getTime() / 1000)),
        max_connections: String(user.max_connections),
        allowed_output_formats: ['m3u8', 'ts', 'rtmp'],
      },
      server_info: {
        url: req.hostname,
        port: String(PORT),
        https_port: String(PORT),
        server_protocol: req.protocol,
        rtmp_port: '0',
        timezone: 'UTC',
        timestamp_now: Math.floor(Date.now() / 1000),
        time_now: new Date().toISOString(),
      }
    });
  }

  // Forward all other actions upstream
  try {
    const { username: _u, password: _p, ...upstreamParams } = req.query;
    const data = await upstreamXC(upstreamParams);
    return res.json(data);
  } catch (e) {
    console.error('Upstream error:', e.message);
    return res.status(502).json({ error: 'Upstream error', detail: e.message });
  }
});

// ─── M3U playlist endpoint ────────────────────────────────────────────────────
app.get('/get.php', async (req, res) => {
  const { username, password } = req.query;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');

  try {
    const upstreamRes = await axios.get(`${UPSTREAM_URL}/get.php`, {
      params: { username: UPSTREAM_USERNAME, password: UPSTREAM_PASSWORD, type: req.query.type || 'm3u_plus', output: req.query.output || 'ts' },
      responseType: 'text',
      timeout: 30000,
    });

    // Rewrite upstream URLs to point to this proxy, with the sub-user's credentials
    const host = `${req.protocol}://${req.get('host')}`;
    let m3u = upstreamRes.data;
    m3u = m3u.replace(new RegExp(UPSTREAM_URL.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), host);
    m3u = m3u.replace(
      new RegExp(`/${UPSTREAM_USERNAME}/${UPSTREAM_PASSWORD}/`, 'g'),
      `/${username}/${password}/`
    );

    res.set('Content-Type', 'application/x-mpegurl');
    return res.send(m3u);
  } catch (e) {
    return res.status(502).send('Upstream error');
  }
});

// ─── EPG / XMLTV proxy ────────────────────────────────────────────────────────
app.get('/xmltv.php', async (req, res) => {
  const { username, password } = req.query;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');

  try {
    const upstreamRes = await axios.get(`${UPSTREAM_URL}/xmltv.php`, {
      params: { username: UPSTREAM_USERNAME, password: UPSTREAM_PASSWORD },
      responseType: 'text',
      timeout: 60000,
    });
    res.set('Content-Type', 'application/xml');
    return res.send(upstreamRes.data);
  } catch (e) {
    return res.status(502).send('Upstream EPG error');
  }
});

// ─── Stream proxy: /live/:user/:pass/:streamId  ───────────────────────────────
app.get('/live/:username/:password/:streamFile', async (req, res) => {
  const { username, password, streamFile } = req.params;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');

  // Enforce max connections
  const activeCons = getActiveConnectionsForUser(username);
  if (activeCons >= user.max_connections) {
    console.log(`[stream] ${username} exceeded max connections (${activeCons}/${user.max_connections})`);
    return res.status(403).send('Max connections reached');
  }

  const streamId = streamFile.split('.')[0];
  const connId = crypto.randomUUID();
  const connMeta = { username, stream_id: streamId, stream_name: streamFile, started_at: new Date().toISOString() };
  activeConnections.set(connId, { ...connMeta, res });
  console.log(`[stream] OPEN  ${username} -> ${streamFile} (conn: ${connId})`);

  const upstreamStreamUrl = `${UPSTREAM_URL}/live/${UPSTREAM_USERNAME}/${UPSTREAM_PASSWORD}/${streamFile}`;
  try {
    const upstream = await axios.get(upstreamStreamUrl, {
      responseType: 'stream',
      timeout: 10000,
    });
    res.set('Content-Type', upstream.headers['content-type'] || 'video/mp2t');
    upstream.data.pipe(res);
    upstream.data.on('error', () => {
      activeConnections.delete(connId);
      res.end();
    });
    req.on('close', () => {
      activeConnections.delete(connId);
      upstream.data.destroy();
      console.log(`[stream] CLOSE ${username} -> ${streamFile} (conn: ${connId})`);
    });
  } catch (e) {
    activeConnections.delete(connId);
    res.status(502).send('Stream error');
  }
});

// ─── VOD / timeshift proxy ────────────────────────────────────────────────────
app.get('/:type(timeshift|movie|series)/:username/:password/*', async (req, res) => {
  const { username, password, type } = req.params;
  const user = lookupUser(username, password);
  if (!user) return res.status(401).send('Unauthorized');

  const activeCons = getActiveConnectionsForUser(username);
  if (activeCons >= user.max_connections) return res.status(403).send('Max connections reached');

  const rest = req.params[0];
  const connId = crypto.randomUUID();
  activeConnections.set(connId, { username, stream_id: rest, stream_name: `${type}/${rest}`, started_at: new Date().toISOString(), res });

  const upstreamUrl = `${UPSTREAM_URL}/${type}/${UPSTREAM_USERNAME}/${UPSTREAM_PASSWORD}/${rest}`;
  try {
    const upstream = await axios.get(upstreamUrl, { responseType: 'stream', timeout: 10000 });
    res.set('Content-Type', upstream.headers['content-type'] || 'video/mp2t');
    upstream.data.pipe(res);
    req.on('close', () => { activeConnections.delete(connId); upstream.data.destroy(); });
    upstream.data.on('error', () => { activeConnections.delete(connId); res.end(); });
  } catch (e) {
    activeConnections.delete(connId);
    res.status(502).send('Stream error');
  }
});

// ─── Admin API ────────────────────────────────────────────────────────────────

// Active connections
app.get('/admin/api/connections', adminAuth, (req, res) => {
  res.json(getAllActiveConnections());
});

// Kick a connection
app.delete('/admin/api/connections/:id', adminAuth, (req, res) => {
  const conn = activeConnections.get(req.params.id);
  if (!conn) return res.status(404).json({ error: 'Connection not found' });
  try { conn.res.end(); } catch (e) {}
  activeConnections.delete(req.params.id);
  res.json({ ok: true });
});

// List users
app.get('/admin/api/users', adminAuth, (req, res) => {
  const users = db.prepare('SELECT * FROM sub_users ORDER BY created_at DESC').all();
  res.json(users.map(u => ({ ...u, days_remaining: daysUntilExpiry(u.expires_at) })));
});

// Create user
app.post('/admin/api/users', adminAuth, (req, res) => {
  const { username, password, display_name, expires_at, max_connections, notes } = req.body;
  if (!username) return res.status(400).json({ error: 'username is required' });

  const pass = password || genPassword();
  try {
    const info = db.prepare(`
      INSERT INTO sub_users (username, password, display_name, expires_at, max_connections, notes)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(username, pass, display_name || username, expires_at || null, max_connections || 1, notes || null);

    const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json({ ...user, days_remaining: daysUntilExpiry(user.expires_at) });
  } catch (e) {
    if (e.message.includes('UNIQUE')) return res.status(409).json({ error: 'Username already exists' });
    res.status(500).json({ error: e.message });
  }
});

// Update user
app.patch('/admin/api/users/:id', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });

  const { display_name, expires_at, max_connections, notes, active, password } = req.body;

  db.prepare(`
    UPDATE sub_users SET
      display_name    = COALESCE(?, display_name),
      expires_at      = ?,
      max_connections = COALESCE(?, max_connections),
      notes           = COALESCE(?, notes),
      active          = COALESCE(?, active),
      password        = COALESCE(?, password)
    WHERE id = ?
  `).run(
    display_name ?? null,
    expires_at !== undefined ? expires_at : user.expires_at,
    max_connections ?? null,
    notes ?? null,
    active !== undefined ? (active ? 1 : 0) : null,
    password ?? null,
    req.params.id
  );

  const updated = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  res.json({ ...updated, days_remaining: daysUntilExpiry(updated.expires_at) });
});

// Renew expiry
app.post('/admin/api/users/:id/renew', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });

  const days = parseInt(req.body.days || 30);
  const base = user.expires_at && new Date(user.expires_at) > new Date()
    ? new Date(user.expires_at)
    : new Date();
  base.setDate(base.getDate() + days);
  const newExpiry = base.toISOString().slice(0, 10);

  db.prepare('UPDATE sub_users SET expires_at = ?, active = 1 WHERE id = ?').run(newExpiry, req.params.id);
  const updated = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  res.json({ ...updated, days_remaining: daysUntilExpiry(updated.expires_at) });
});

// Delete user
app.delete('/admin/api/users/:id', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  db.prepare('DELETE FROM sub_users WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// Get XC connection info
app.get('/admin/api/users/:id/xc-info', adminAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM sub_users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });

  const base = `${req.protocol}://${req.get('host')}`;
  res.json({
    server_url: base,
    username: user.username,
    password: user.password,
    m3u_url: `${base}/get.php?username=${user.username}&password=${user.password}&type=m3u_plus`,
    epg_url: `${base}/xmltv.php?username=${user.username}&password=${user.password}`,
    xc_url: `${base}/player_api.php?username=${user.username}&password=${user.password}`,
  });
});

// Server stats
app.get('/admin/api/stats', adminAuth, (req, res) => {
  const total   = db.prepare('SELECT COUNT(*) as c FROM sub_users').get().c;
  const active  = db.prepare("SELECT COUNT(*) as c FROM sub_users WHERE active = 1 AND (expires_at IS NULL OR expires_at >= date('now'))").get().c;
  const expired = db.prepare("SELECT COUNT(*) as c FROM sub_users WHERE expires_at IS NOT NULL AND expires_at < date('now')").get().c;
  res.json({ total, active, expired });
});

// Test upstream connectivity
app.get('/admin/api/test-upstream', adminAuth, async (req, res) => {
  try {
    const data = await upstreamXC({});
    res.json({ ok: true, upstream_user: data.user_info?.username || UPSTREAM_USERNAME });
  } catch (e) {
    res.status(502).json({ ok: false, error: e.message });
  }
});

// ─── Cron: disable expired users (runs hourly) ────────────────────────────────
cron.schedule('0 * * * *', () => {
  const result = db.prepare(`
    UPDATE sub_users SET active = 0
    WHERE active = 1 AND expires_at IS NOT NULL AND expires_at < date('now')
  `).run();
  if (result.changes > 0) console.log(`[cron] Disabled ${result.changes} expired user(s)`);
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ Dispatcharr User Manager running on port ${PORT}`);
  console.log(`   Upstream: ${UPSTREAM_URL} (user: ${UPSTREAM_USERNAME})`);
  console.log(`   Admin UI: http://localhost:${PORT}/admin`);
});
